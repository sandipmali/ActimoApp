﻿using System;

namespace Actimo.Data.Accesor
{
    public class Class1
    {
    }
}
