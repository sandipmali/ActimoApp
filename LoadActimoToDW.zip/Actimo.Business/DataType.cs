﻿using System;

namespace Actimo.Business
{
    public enum DataType
    {
        Contacts,
        ContactManager,
        Engagement
    }
}
